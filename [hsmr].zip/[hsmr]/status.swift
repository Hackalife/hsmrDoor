//
//  status.swift
//  [hsmr]
//
//  Created by Hackalife Ali on 7/4/17.
//  Copyright © 2017 Hackalife Ali. All rights reserved.
//

import Foundation

struct status {
    let Tstatus:String
}

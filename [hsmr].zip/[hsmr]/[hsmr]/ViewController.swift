//
//  ViewController.swift
//  [hsmr]
//
//  Created by Hackalife Ali on 7/4/17.
//  Copyright © 2017 Hackalife Ali. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Doorstatus: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let DoorstatusURL = URL(string: "https://hsmr.cc")
        let DoorstatusURLRequest = URLRequest(url: DoorstatusURL!)
        Doorstatus.loadRequest(DoorstatusURLRequest)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

